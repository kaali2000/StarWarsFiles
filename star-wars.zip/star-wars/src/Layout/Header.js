import React from "react";
import classes from './Header.module.css';
import starwarsImg from '../assets/starwarsLogo.png';

const Header = () => {
  return (
    <div>
      <header className={classes.header}>
        <div className={classes['logo-image']}><img src={ starwarsImg } alt="Logo" /></div>
      </header>
    </div>
  );
};

export default Header;
