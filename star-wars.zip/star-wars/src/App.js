import React from 'react';
import './App.css';
import Header from './Layout/Header';
import Ships from './Ships/Ships';

function App() {
  return (
    <div className="App">
      <Header />
      <Ships />
    </div>
  );
}

export default App;
