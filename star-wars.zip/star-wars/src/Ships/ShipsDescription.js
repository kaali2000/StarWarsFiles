import React from "react";

import classes from "./ShipsDescription.module.css";
import Button from "../UI/Button";
import cupImg from "../assets/cup.png";

const ShipsDescription = () => {
  return (
    <section className={classes.summary}>
      <h2>Sample Vue 3 project using the SWAPI API</h2>
      <p>
        Results are filtered to starships with a crew size less than 10 and
        sorted by crew size
      </p>
      <p>
        The starship that has featured in the most films will show a{" "}
        <img src={cupImg} alt="Cup" />
      </p>
      <Button />
    </section>
  );
};

export default ShipsDescription;
