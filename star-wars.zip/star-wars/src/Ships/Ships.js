import React from 'react';

import ShipsDescription from './ShipsDescription';
import AvailableStarships from './AvailableStarships';

const Ships = () => {
    return (<div>
        <ShipsDescription />
        <AvailableStarships />
    </div>);
};

export default Ships;