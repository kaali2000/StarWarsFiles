import React, { useEffect, useState } from "react";
import classes from "./AvailableStarships.module.css";
import Card from "../UI/Card";

const AvailableStarships = () => {
  const [data, setData] = useState([]);
  const fetchData = async () => {
    const response = await fetch("https://swapi.dev/api/starships/",
      {
        method: 'GET', headers: {'Content-Type': 'application/json'}
      }
    );
    const result = await response.json();
    setData(result);
  };
  useEffect(() => {
    fetchData();
  }, []);

  return (
    <section className={classes.ships}>
      <Card>
        <ul>
          {Array.isArray(data.results) ? data.results.map((ship) => (
            <li className={classes.starships} key={ship.id}>
            <div className={classes.firstCol}>
              <h3>{ship.name}</h3>
              <div className={classes.model}>Model: {ship.model}</div>
            </div>
            <div className={classes.secondCol}>
              <div className={classes.films}>No of films: {ship.films.length}</div>
            </div>
          </li>)) : ''}
        </ul>
      </Card>
    </section>
  );
};

export default AvailableStarships;
